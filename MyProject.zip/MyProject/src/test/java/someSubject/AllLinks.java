package someSubject;

public class AllLinks {

}
